## Source Code Link

1. [EM algorithm for Gaussian mixture model](http://www.mathworks.com/matlabcentral/fileexchange/26184-em-algorithm-for-gaussian-mixture-model)