load data; 
label = emgm(x,3); 
spread(x,label);