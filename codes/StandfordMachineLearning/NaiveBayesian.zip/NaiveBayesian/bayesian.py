#!/usr/bin/env python
# *-* coding=utf-8 *-*

'Bayesian Classification'

__author__='xiahouzuoxin'

import logging
logging.basicConfig(level=logging.INFO)

class NaiveBayesian(object):

    def __init__(self, train_data, train_label, predict_data=None, predict_label=None):
        self.train_data = train_data
        self.train_label = train_label
        self.m = len(self.train_label)  # 样本数目
        self.n = len(train_data[1]);  # 特征数目，假设特征维度一样
        self.cls = list(set(train_label));
        self.predict_data = predict_data
        self.predict_label = predict_label
        self.__prio_p = {}
        self.__likelihood_p = {}
        self.__evidence_p = 1
        self.__predict_p = [];

    def train(self):
        # 统计目标出现概率：先验概率
        p_lb = {}
        for lb in self.train_label:
            if lb in p_lb:  
                p_lb[lb] = p_lb[lb] + 1
            else:
                p_lb[lb] = 1+1  # Laplace smoothing，初始为1，计数+1
        for lb in p_lb.keys():
            p_lb[lb] = float(p_lb[lb]) / (self.m+len(self.cls))
        self.__prio_p = p_lb

        # 统计都有啥特征
        p_v = {}
        feat_key = [];
        for sample in self.train_data:
            #print sample
            for k,v in sample.iteritems():
                feat_key.append((k,v))
                if (k,v) in p_v:
                    p_v[(k,v)] = p_v[(k,v)] + 1
                else:
                    p_v[(k,v)] = 1+1  # Laplace smoothing
        for v in p_v:
            p_v[v] = float(p_v[v]) / (self.m+p_v[v])
            self.__evidence_p *= p_v[v]  # 条件独立假设
        
        # 统计似然概率
        keys = [(x,y) for x in self.cls for y in feat_key]
        keys = set(keys)
        p_likelihood = {};
        for val in keys:
            p_likelihood[val]=1    # Laplace smoothing, 初始计数为1
        for idx in range(self.m):  # 统计频次
            p_likelihood[(self.train_label[idx],feat_key[idx])] = p_likelihood[(self.train_label[idx],feat_key[idx])] + 1
        for k in p_likelihood:  # 求概率
            if self.cls[0] in k:
                p_likelihood[k] = float(p_likelihood[k]) / (self.m*self.__prio_p[self.cls[0]]+2)
            else:
                p_likelihood[k] = float(p_likelihood[k]) / (self.m*self.__prio_p[self.cls[1]]+2)
        self.__likelihood_p = p_likelihood
    
    def predict(self):
        label = [];
        for x_dict in self.predict_data:  # 可以处理多维特征的情况
            likeli_p = [1,1];
            for key,val in x_dict.iteritems():  
                likeli_p[0] = likeli_p[0] * self.__likelihood_p[(self.cls[0], (key,val))]  # 条件独立假设
                likeli_p[1] = likeli_p[1] * self.__likelihood_p[(self.cls[1], (key,val))]

            p_predict_cls0 = likeli_p[0] * self.__prio_p[self.cls[0]] / self.__evidence_p
            p_predict_cls1 = likeli_p[1] * self.__prio_p[self.cls[1]] / self.__evidence_p
            norm = p_predict_cls0 + p_predict_cls1
            p_predict_cls0 = p_predict_cls0/norm
            p_predict_cls1 = p_predict_cls1/norm
            self.__predict_p.append({self.cls[0]:p_predict_cls0})
            self.__predict_p.append({self.cls[1]:p_predict_cls1})
            if p_predict_cls1 > p_predict_cls0:
                label.append(self.cls[1])
            else:
                label.append(self.cls[0])

        return label,self.__predict_p

    def get_prio(self):
        return self.__prio_p

    def get_likelyhood(self):
        return self.__likelihood_p

