#!/usr/bin/env python
# *-* coding=utf-8 *-*

__author__='xiahouzuoxin'

import bayesian


# 一维特征情况
# train_data = [ {'Name':'Drew'},
#         {'Name':'Claudia'},
#         {'Name':'Drew'},
#         {'Name':'Drew'},
#         {'Name':'Alberto'},
#         {'Name':'Karin'}, 
#         {'Name':'Nina'},
#         {'Name':'Sergio'} ]
# train_label = ['Male','Female','Female','Female','Male','Female','Female','Male']
# predict_data = [{'Name':'Drew'}]
# predict_label = None;

# 多维特征的情况
train_data = [ {'Name':'Drew','Over170':'No','Eye':'Blue','Hair':'Short'},
        {'Name':'Claudia','Over170':'Yes','Eye':'Brown','Hair':'Long'},
        {'Name':'Drew','Over170':'No','Eye':'Blue','Hair':'Long'},
        {'Name':'Drew','Over170':'No','Eye':'Blue','Hair':'Long'},
        {'Name':'Alberto','Over170':'Yes','Eye':'Brown','Hair':'Short'},
        {'Name':'Karin','Over170':'No','Eye':'Blue','Hair':'Long'}, 
        {'Name':'Nina','Over170':'Yes','Eye':'Brown','Hair':'Short'},
        {'Name':'Sergio','Over170':'Yes','Eye':'Blue','Hair':'Long'} ]
train_label = ['Male','Female','Female','Female','Male','Female','Female','Male']
predict_data = [{'Name':'Drew','Over170':'Yes','Eye':'Blue','Hair':'Long'}]
predict_label = None;

model = bayesian.NaiveBayesian(train_data, train_label, predict_data, predict_label)
model.train()
result = model.predict()
print result



